package com.example.kiran.simple_login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {
    private static EditText user;
    private  static EditText pass;
    private static Button b;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        LoginButton();
    }

    public void LoginButton(){
        user=(EditText)findViewById(R.id.editText2);
        pass=(EditText)findViewById(R.id.editText);
        b=(Button)findViewById(R.id.button);

        b.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if((user.getText().toString().equals("User"))&&
                                (pass.getText().toString().equals("Password"))){

                            Toast.makeText(login.this,"Correct",
                                    Toast.LENGTH_LONG).show();
                        Intent i=new Intent(".user");
                        startActivity(i);}

                        else
                            Toast.makeText(login.this,"Incorrect",
                                    Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }
}
